#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>

using namespace std;

#pragma pack(push)
#pragma pack(1)

struct Founder
{
    char fullname[100];
    int age;
    char Qualification[100];
};

struct Product
{
    char description[100];
    int price;
    int numdownloads;
};

struct Company
{
    char name[100];
    int valuation;
    char sector[100];
    int numemployees;
    Founder * founders;
    Product *products;

};

#pragma pack(pop)

int main()
{
    int numfounders ;
    int numproducts;
    int numCompanies;
    int Max;
    int Value ;
    int max_price;
    int index =0;
    cout<<"Please enter the number of companies"<<endl;
    cin>>numCompanies;
    Company company[numCompanies];
    cout << "Please enter the information of the companies:" << endl << endl;
    for(int i=0; i < numCompanies; i++)
    {
    cout << "What is the Company name? (NO SPACES)" << endl;
    cin >> company[i].name;
    cout << "the Company's valuation?" << endl;
    cin >> company[i].valuation;
    cout << "Company sector of operation?" << endl;
    cin >> company[i].sector;
    cout << "what is the Number of employees?" << endl;
    cin >> company[i].numemployees;
    cout << endl << endl;
    Value += company[i].valuation;
    cout << "How many founders for " << company[i].name << "?" << endl;
    cin>>numfounders;
    company[i].founders=new Founder[numfounders];
    for(int f = 0; f < numfounders; f++)
    {
        cout << "Please enter founder information." << endl << endl;
        cout << "Founder name?" << endl;
        cin >> company[i].founders[f].fullname;
        cout << "Founder age?" << endl;
        cin >> company[i].founders[f].age;
        cout << "Highest Qualification of founder?" << endl;
        cin >> company[i].founders[f].Qualification;

    }
    for(int c=0; c < numfounders ; c++)
    {
        Max =company[i].founders[0].age;
         if(Max > company[i].founders[c].age)
        {
            Max = company[i].founders[c].age;
        }
    }
    cout << endl << endl;
    cout << "How many products for " << company[i].name << "?" << endl;
    cin>> numproducts;
    company[i].products=new Product[numproducts];
    for(int p = 0; p < numproducts; p++)
    {
        cout << "Please enter product information." << endl << endl;
        cout << "Product description?" << endl;
        cin >> company[i].products[p].description;
        cout << "Price of using app?" << endl;
        cin >> company[i].products[p].price;
        cout << "Number of downloads?" << endl;
        cin >> company[i].products[p].numdownloads;
    }
    for(int m=0; m < numproducts; m++ )
    {
        max_price = company[i].products[0].price;
        if(max_price < company[i].products[m].price)
        {
            max_price = company[i].products[m].price;
            index = m;
        }
    }
  }
  cout<<"the total value of the companies is: "<<Value<<endl;
  cout<<"the youngest founder is: "<<Max<<endl;

    cout << endl << endl;

    fstream file;



    file.open("company.txt",ios::binary|ios::out);
    file.write(reinterpret_cast<char*>(&company), sizeof(company));

    file.setf(ios::fixed);
    file.precision(3);
    for(int i=0 ; i < numCompanies ; i++)
    {

    file <<"the company's name: "<< company[i].name << endl;
    file <<"the company's valaution: "<<company[i].valuation << endl;
    file <<"the sector the company operates in is: "<<company[i].sector << endl;
    file <<"the number of employees in the company is: "<<company[i].numemployees << endl;
    for(int f = 0; f < numfounders; f++)
    {
        file <<"the number of founders for the company is: "<<company[i].founders[f].fullname << endl;
        file <<"the age of founder "<<f+1<<" is: "<<company[i].founders[f].age << endl;
        file <<"the highest qualification for founder "<<f+1<<" is: "<<company[i].founders[f].Qualification << endl;
    }


    for(int p = 0; p < numproducts; p++)
    {
        file<<"the description of the product:  "<< company[i].products[p].description << endl;
        file<<"the price of the product :"<< company[i].products[p].price << endl;
        file<<"the number of download for the products :"<< company[i].products[p].numdownloads << endl;
    }
    file.width(7);
    }

    file.close();


    file.open("company.txt", ios::in | ios::binary);
    file.seekg(0,ios::end);
    int numbytes = file.tellg();
    int records = numbytes/sizeof(company);
    for(int i =0; i < records; i++)
    {
        Company Temp;
        file.seekg(i * sizeof(Company), ios::beg);
        file.read(reinterpret_cast<char*>(&Temp), sizeof(Company));
    cout<<"the company's name: "<< Temp.name << endl;
    cout <<"the company's valaution: "<<Temp.valuation << endl;
    cout <<"the sector the company operates in is: "<<Temp.sector << endl;
    cout <<"the number of employees in the company is: "<<Temp.numemployees << endl;

    file.close();

    }


    return 0;
}
